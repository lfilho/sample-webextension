const METRIC_ENDPOINT = 'https://fake-duckduckgo-endpoint.com/metrics';
const FEEDBACK_ENDPOINT = 'https://fake-duckduckgo-endpoint.com/feedback';

export { METRIC_ENDPOINT, FEEDBACK_ENDPOINT };
