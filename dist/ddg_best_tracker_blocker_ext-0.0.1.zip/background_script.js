console.log('This is coming from background script!');
