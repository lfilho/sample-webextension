import RequestBlocker from './request_blocker.js';

console.log('Extension is ready to start blocking!');
RequestBlocker.startMonitoring();
